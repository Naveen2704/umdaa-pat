import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VersiontwoService {
  public apiUrl = environment.baseUrl;
  constructor( private _http:HttpClient) { }
  addOcr(followdays,result,app_id):Observable<any>{
    console.log(result)
    console.log(result.investigations);
    console.log(result.prescription);
    for(var i=0;i<result.clnotes.length;i++){
      console.log(result.clnotes[i].clnotes);
    }
    return this._http.post(this.apiUrl,
      {
        "requesterid": 3,
        "requestname": "saveOcr",
        "requestparameters": {
            "appointment_id": app_id,
            "vitals": {
                "PR": result.vitals.PR,
                "SBP": result.vitals.SBP,
                "DBP":result.vitals.DBP,
                "RR": result.vitals.RR,
                "Temp": result.vitals.Temp,
                "SaO2": result.vitals.SaO2,
                "Height": result.vitals.Height,
                "Weight": result.vitals.weight,
                "BMI": result.vitals.BMI,
                "BSA": result.vitals.BSA,
                "WH": result.vitals.WH,
                "allergy": result.vitals.allergy,
            },
            "clnotes": result.clnotes,
            "pastnotes":result.pastnotes,
            "cd": result.cd,
            "investigations": result.investigations,
            "prescription": result.prescription,
            "gen": result.gi,
            "plan":result.plan.plan_notes,
            "followupdate": followdays
        }
    }
  )
  }
}
