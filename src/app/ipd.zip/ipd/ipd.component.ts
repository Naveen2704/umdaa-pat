import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormBuilder, FormGroupDirective, FormGroup, Validators } from '@angular/forms';
import { ListService } from '../lists/list.service';
import { PatientserviceService } from '../service/patientservice.service';
import { NotificationService } from '../shared/notification.service';
import { timeStamp } from 'console';

const bullet = "\u2022";
const bulletWithSpace = `${bullet} `;
const enter = 13;

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-ipd',
  templateUrl: './ipd.component.html',
  styleUrls: ['./ipd.component.css']
})

export class IpdComponent implements OnInit {
  ipdSubjective: any;
  ipdObjective:any;
  ipdAnalysis:any;
  ipdPlan:any;
  presentationForm:any;
  primaryConsultant:any;
  candmForm:any;
  fuForm:any;
  crossForm:any;
  consultantForm:any;
  id: any;
  show:boolean = true;
  hide:boolean = false;
  rounds: any=[];
  FirstObjective: any;
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  doctorsList: any=[];
  crossNotes: any;
  crossDoctorName: any;
  id2: any;
  disabled: boolean = false;
  hideLoading:boolean = false;
  showLoading:boolean = true;
  hideDischargeLoading:boolean = false;
  showDischargeLoading:boolean = true;
  constructor(private _notification:NotificationService,private patientservice:PatientserviceService,private route: ActivatedRoute,public router: Router,public _fb :FormBuilder,private service:ListService) { }

  ngOnInit() {
    this.getClinicDoctor('1');
    this.ipdSubjective = this._fb.group({
      subjective:new FormControl('', Validators.required)
    });
    this.ipdObjective = this._fb.group({
      objective:new FormControl('', Validators.required)
    });
    this.ipdAnalysis = this._fb.group({
      analysis:new FormControl('', Validators.required)
    });
    this.ipdPlan = this._fb.group({
      plan:new FormControl('', Validators.required)
    });
    this.crossForm = this._fb.group({
      CrossNotes:new FormControl('', Validators.required),
      // doc_name:new FormControl('', Validators.required),
    });

    this.presentationForm = this._fb.group({
      presentation:new FormControl('', Validators.required),
    });

    this.candmForm = this._fb.group({
      CandM:new FormControl('', Validators.required),
    });

    this.fuForm = this._fb.group({
      followUp:new FormControl('', Validators.required),
    });

    this.primaryConsultant = this._fb.group({
      pConsultant:new FormControl('', Validators.required),
    })

    this.consultantForm = this._fb.group({
      consultant:new FormControl('', Validators.required),
    })

    this.route.params.subscribe(res => {
      this.id =  res['id'];
      this.id2 =  res['id1'];
      console.log(this.id);
      this.getPatientInfo(this.id)
    });
  }

  getClinicDoctor(clinic_id)
  {
    this.service.getClinicDoctorInfo(clinic_id).subscribe(res =>{
      console.log(res);
      this.doctorsList = res['result'].Doctor;
      console.log(this.doctorsList);
    });
  }

  getPatientInfo(id)
  {
    this.patientservice.Getdetails(id).subscribe(res =>{
      console.log(res);
      console.log(res['result']['parameters'][0]);
      console.log(res['result']['parameters'][0].doctor_id);
      console.log(res['result']['parameters'][0].patient_id);
      console.log(res['result']['parameters'][0].appointment_id);
      localStorage.setItem('doctor_id',res['result']['parameters'][0].doctor_id);
      localStorage.setItem('patient_id',res['result']['parameters'][0].patient_id);
      localStorage.setItem('appointment_id',res['result']['parameters'][0].appointment_id);
    });
  }
  
  
  handleInput(event){
    const { keyCode, target } = event;
    const { selectionStart, value } = target;
    
    if (keyCode === enter || keyCode == 13) {
      // console.log('a');
      target.value = [...value]
        .map((c, i) => i === selectionStart - 1
          ? `\n${bulletWithSpace}`
          : c
        )
        .join('');
        console.log(target.value);
        
      target.selectionStart = selectionStart+bulletWithSpace.length;
      target.selectionEnd = selectionStart+bulletWithSpace.length;
    }
    
    if (value[0] !== bullet) {
      target.value = `${bulletWithSpace}${value}`;
    }
  }

  presribe()
  {
    this.router.navigate(['/ipdPrescription/'+this.id+'/'+this.id2]);
  }

  subSubmit(data,form)
  {
    console.log(data,form);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(doctor_id);
    console.log(patient_id);
    console.log(appointment_id);
    this.service.subjective(data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Subjective Added ');
    });
    this.ipdSubjective.reset();
  }

  objSubmit(data,form)
  {
    console.log(data,form);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(doctor_id);
    console.log(patient_id);
    console.log(appointment_id);
    this.service.objective(data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Objective Added ');
    });
    this.ipdObjective.reset();
  }

  analysisSubject(data,form)
  {
    console.log(data,form);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(doctor_id);
    console.log(patient_id);
    console.log(appointment_id);
    this.service.analysis(data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Analysis Added ');
    });
    this.ipdAnalysis.reset();
  }

  submitIpdPlan(data,form)
  {
    console.log(data);
    console.log(form)
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(doctor_id);
    console.log(patient_id);
    console.log(appointment_id);
    this.service.plan(data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Plan Added ');
    });
    this.ipdPlan.reset();
  }

  viewTimeLines()
  {
    this.getRoundsInfo();
    this.show = false;
    this.hide = true;
    // alert("check");
  }

  back()
  {
    this.show = true;
    this.hide = false;
  }

  getRoundsInfo()
  {
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(doctor_id);
    console.log(patient_id);
    console.log(appointment_id);
    this.service.getRounds(appointment_id,doctor_id,patient_id).subscribe((res)=>{
      console.log(res);
      console.log(res['result']['Rounds']);
      this.rounds = res['result']['Rounds'];
      console.log(this.rounds);
      console.log(this.rounds[0].objective);
      // this.FirstObjective = this.rounds[0].objective;
    //   this.ipdObjective.setValue({
    //     objective: this.rounds[0].objective
    //  });
      // this._notification.success('Analysis Added ');
    });
  }

  crossNotesSubmit(data,form)
  {
    console.log(data);
    // var doctor_id = localStorage.getItem('doctor_id');
    // var patient_id =localStorage.getItem('patient_id');
    // var appointment_id = this.id;
    // this.service.crossNotes(appointment_id,doctor_id,patient_id).subscribe((res)=>{
    //   console.log(res);
    //   console.log(res['result']['Rounds']);
    //   this.rounds = res['result']['Rounds'];
    //   console.log(this.rounds);
    //   console.log(this.rounds[0].objective);
    // });
  }

  getCrossNotes(e)
  {
    this.crossNotes = e;
  }


  changeClient(e)
  {
    console.log(e);
    this.crossDoctorName = e;
  }

  
  getCross()
  {
    console.log(this.crossNotes);
    console.log(this.crossDoctorName);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
      this.service.crossNotes(appointment_id,doctor_id,patient_id,this.crossNotes,this.crossDoctorName).subscribe((res)=>{
      console.log(res);
     });
     this.crossForm.reset();
  }

  presentationSubmit(data,form)
  {
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(data,form);
    this.service.presentationSubmit(appointment_id,doctor_id,patient_id,data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Presentation Added ');
     });
     this.presentationForm.reset();
  }

  courseSubmit(data,form)
  {
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(data,form);
    this.service.courseData(appointment_id,doctor_id,patient_id,data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Course and Mangement Added ');
     });
     this.candmForm.reset();
  }

  followUpSubmit(data,form)
  {
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    console.log(data,form);
       this.service.followUpData(appointment_id,doctor_id,patient_id,data).subscribe((res)=>{
        console.log(res);
        this._notification.success('Follow Up Advice Added ');
      });
     this.fuForm.reset();
  }

  pConsultant(data,form)
  {
    console.log(data,form);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    this.service.pConsultant(appointment_id,doctor_id,patient_id,data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Follow Up Advice Added ');
     });
     this.primaryConsultant.reset();
  }

  consultantSubmit(data,form)
  {
    console.log(data,form);
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    this.service.consultant(appointment_id,doctor_id,patient_id,data).subscribe((res)=>{
      console.log(res);
      this._notification.success('Follow Up Advice Added ');
     });
     this.consultantForm.reset();
  }

  getPrint()
  {
    this.hideLoading = true;
    this.showLoading = false;
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    this.service.roundsPdf(doctor_id,patient_id,appointment_id).subscribe((res)=>{
      console.log(res);
      console.log(res['result'].pdf_name);
      window.open(res['result'].pdf_name,'_blank');
      this.hideLoading = false;
      this.showLoading = true;
      // this._notification.success('Follow Up Advice Added ');
     });
  }

  getDischargePrint()
  {
    this.hideDischargeLoading = true;
    this.showDischargeLoading = false;
    var doctor_id = localStorage.getItem('doctor_id');
    var patient_id =localStorage.getItem('patient_id');
    var appointment_id = this.id;
    this.service.dischargePdf(doctor_id,patient_id,appointment_id).subscribe((res)=>{
      console.log(res);
      console.log(res['result'].pdf_name);
      window.open(res['result'].pdf_name,'_blank');
      this.hideDischargeLoading = false;
      this.showDischargeLoading = true;
      // this._notification.success('Follow Up Advice Added ');
     });
  }
}
